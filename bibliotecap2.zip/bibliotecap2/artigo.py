class ArtigoCientifico:
    def __init__(self, id, titulo, resumo, autor, detalhe_autor, download):
        self.id=id
        self.titulo=titulo
        self.resumo=resumo
        self.autor=autor
        self.detalhe_autor=detalhe_autor
        self.download=download