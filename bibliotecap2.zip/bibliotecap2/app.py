from livro import Livro
from artigo import ArtigoCientifico
from revista import Revista
from jornal import Jornal
from flask import Flask, render_template

app = Flask(__name__)

# Lista de livros
livros_biblioteca = [
    Livro(
        id=1,
        titulo="Segredos do Cosmos",
        descricao="A renomada astrofísica, Dra. Helena Castro, descobre uma mensagem enigmática proveniente de uma civilização alienígena. À medida que decifra o código, ela embarca em uma jornada intergaláctica que revela os mistérios do universo e desafia tudo o que conhecemos sobre a vida e a existência. Em meio a aventuras espaciais e dilemas éticos, Helena precisa decidir entre compartilhar sua descoberta com a humanidade ou proteger segredos que podem alterar o destino de nossa espécie.",
        autor="Helena Prado",
        detalhe_autor="Helena Prado nasceu em São Paulo, Brasil, e desde jovem demonstrou uma paixão intensa por astronomia e ciências exatas. Formada em Física pela Universidade de São Paulo (USP), continuou seus estudos em astrofísica na Universidade de Cambridge, onde obteve seu doutorado. Helena trabalhou em importantes observatórios ao redor do mundo e publicou inúmeros artigos científicos. Além de suas contribuições acadêmicas, Helena sempre teve um amor pela escrita, o que a levou a mesclar sua experiência científica com a ficção, criando obras que exploram os mistérios do universo. 'Segredos do Cosmos' é seu romance de estreia, onde ela combina rigor científico com uma narrativa envolvente.",
        categoria="Ficção Científica",
        disponibilidade="50 unidades",
        reserva="É possível reservar"),
    
    Livro(
        id=2,
        titulo="O Último Refúgio",
        descricao="Em uma cidade onde o crime e a corrupção dominam, o detetive aposentado Leonardo Araújo é chamado para investigar o desaparecimento de uma jovem ativista. Conforme se aprofunda no caso, Leonardo descobre uma rede de mentiras e conspirações que envolve figuras poderosas e segredos sombrios. Sua busca pela verdade não apenas coloca sua vida em risco, mas também o obriga a confrontar fantasmas do passado e decidir até onde está disposto a ir para alcançar justiça.",
        autor="Miguel Albuquerque",
        detalhe_autor="Miguel Albuquerque nasceu no Rio de Janeiro, Brasil, e cresceu rodeado pelas histórias e mistérios das ruas da cidade. Após se formar em Direito pela Universidade Federal do Rio de Janeiro (UFRJ), Miguel ingressou na polícia civil, onde trabalhou como detetive por mais de duas décadas. Sua experiência em investigação criminal e sua habilidade em desvendar complexos casos de corrupção e crime organizado o tornaram uma lenda no departamento. Ao se aposentar, Miguel decidiu usar suas vivências e conhecimentos para escrever thrillers repletos de suspense e realismo. 'O Último Refúgio' é seu segundo livro, consolidando sua reputação como um mestre do gênero.",
        categoria="Suspense/Thriller",
        disponibilidade="0 unidades",
        reserva="Não é possível reservar"),

]

# Lista de artigos científicos
artigos_biblioteca = [
    ArtigoCientifico(
        id=1,
        titulo="Detecção e Decodificação de Sinais Extraterrestres: Novas Perspectivas na Astrofísica",
        resumo="Este artigo apresenta uma análise detalhada da detecção e decodificação de um sinal extraterrestre capturado pelo radiotelescópio ALMA. Liderada pela Dra. Helena Castro, a pesquisa explora as metodologias empregadas para identificar a origem do sinal, os algoritmos desenvolvidos para sua decodificação e as implicações dessa descoberta para a compreensão da vida extraterrestre. Além disso, o artigo discute os desafios éticos e científicos decorrentes da comunicação com civilizações alienígenas e propõe um protocolo para futuras interações intergalácticas.",
        autor="Isabela Mendes",
        detalhe_autor="Isabela Mendes nasceu em Porto Alegre, Brasil, e desde jovem demonstrou uma paixão intensa por astronomia e ciências exatas. Formada em Física pela Universidade Federal do Rio Grande do Sul (UFRGS), continuou seus estudos em astrofísica na Universidade de Stanford, onde obteve seu doutorado. Isabela trabalhou em importantes observatórios ao redor do mundo, incluindo o ALMA no Chile e o Very Large Telescope no Chile. Com mais de 60 artigos científicos publicados em revistas de renome, Isabela é uma autoridade no estudo de sinais extraterrestres e na astrofísica teórica. Sua dedicação à pesquisa e à divulgação científica a tornou uma referência em sua área.",
        download="É possível fazer o download deste arquivo."),
    
    ArtigoCientifico(
        id=2,
        titulo="Análise de Redes de Corrupção: Metodologias e Impactos na Segurança Pública",
        resumo="Este estudo investiga as metodologias utilizadas para identificar e desmantelar redes de corrupção dentro de instituições públicas. Ricardo Santana, ex-detetive e especialista em investigação criminal, apresenta uma revisão abrangente de técnicas de análise de redes sociais (SNA) aplicadas à criminologia. O artigo detalha casos reais onde essas metodologias foram implementadas com sucesso, destacando os impactos positivos na segurança pública e a recuperação de confiança nas instituições. Conclui-se com recomendações para aprimoramento das práticas investigativas e sugestões para políticas públicas focadas na prevenção e combate à corrupção.",
        autor="Ricardo Santana",
        detalhe_autor="Ricardo Santana nasceu em Salvador, Brasil, e cresceu rodeado pelas histórias e mistérios das ruas da cidade. Após se formar em Direito pela Universidade Federal da Bahia (UFBA), Ricardo ingressou na polícia civil, onde trabalhou como detetive por mais de duas décadas. Durante sua carreira, Ricardo se especializou em investigações complexas envolvendo corrupção e crime organizado. Sua abordagem inovadora e suas habilidades analíticas levaram à resolução de casos emblemáticos e à implementação de novas técnicas investigativas. Desde sua aposentadoria, Ricardo se dedica à pesquisa acadêmica e à consultoria em segurança pública, contribuindo para o desenvolvimento de políticas eficazes de combate à corrupção.",
        download="Não é possível fazer o download deste arquivo."),
]

# Lista de revistas
revistas_biblioteca = [
    Revista(
        id=1,
        titulo="Revista de Ciências e Tecnologia",
        descricao="Publicação trimestral que aborda os avanços mais recentes em ciência e tecnologia, incluindo artigos de pesquisa, análises de tendências e entrevistas com especialistas.",
        datas_edicao="Janeiro, Abril, Julho, Outubro",
        disponibilidade="Todas as edições desde 2015 estão disponíveis.",
        leitura_online="Disponível para leitura online e download em formato PDF."),
    
    Revista(
        id=2,
        titulo="Revista de Psicologia Aplicada",
        descricao="Publicação mensal focada em psicologia prática e clínica. Traz estudos de caso, artigos teóricos e aplicações práticas das teorias psicológicas.",
        datas_edicao="Todos os meses",
        disponibilidade="Edições desde 2008.",
        leitura_online="Disponível para leitura online e download em formato PDF."),
]

# Lista de jornais
jornais_biblioteca = [
    Jornal(
        id=1,
        titulo="Jornal de Atualidades Científicas",
        descricao="Diário que cobre notícias e descobertas recentes no campo das ciências naturais e exatas. Inclui artigos de opinião e colunas de especialistas",
        datas_edicao="Publicação diária",
        disponibilidade="Arquivo completo desde 2010.",
        leitura_online="Disponível para leitura online e download em formato PDF."),
    
    Jornal(
        id=2,
        titulo="Jornal de Economia e Negócios",
        descricao="Publicação semanal que traz análises profundas sobre o mercado financeiro, economia global e negócios. Inclui entrevistas com líderes empresariais e relatórios de mercado.",
        datas_edicao="Todos as segundas-feiras",
        disponibilidade="Edições desde 2005.",
        leitura_online="Disponível para leitura online e download em formato PDF."),
]

@app.route("/")
def index():
    return render_template("home.html", livros_biblioteca=livros_biblioteca, artigos_biblioteca=artigos_biblioteca, revistas_biblioteca=revistas_biblioteca, jornais_biblioteca=jornais_biblioteca)

@app.route('/livro/<int:id>')
def livro(id):
    livro_selecionado = None
    for livro in livros_biblioteca:
        if livro.id == id:
            livro_selecionado = livro
            break
    if livro_selecionado:
        return render_template('livro.html', livro=livro_selecionado)
    else:
        return "<h1>Erro: Livro não encontrado.</h1>"

@app.route('/artigo/<int:id>')
def artigo(id):
    artigo_selecionado = None
    for artigo in artigos_biblioteca:
        if artigo.id == id:
            artigo_selecionado = artigo
            break
    if artigo_selecionado:
        return render_template('artigo.html', artigo=artigo_selecionado)
    else:
        return "<h1>Erro: Artigo não encontrado.</h1>"
    
@app.route('/revista/<int:id>')
def revista(id):
    revista_selecionado = None
    for revista in revistas_biblioteca:
        if revista.id == id:
            revista_selecionado = revista
            break
    if revista_selecionado:
        return render_template('revista.html', revista=revista_selecionado)
    else:
        return "<h1>Erro: Revista não encontrado.</h1>"
    
@app.route('/jornal/<int:id>')
def jornal(id):
    jornal_selecionado = None
    for jornal in jornais_biblioteca:
        if jornal.id == id:
            jornal_selecionado = jornal
            break
    if jornal_selecionado:
        return render_template('jornal.html', jornal=jornal_selecionado)
    else:
        return "<h1>Erro: Jornal não encontrado.</h1>"