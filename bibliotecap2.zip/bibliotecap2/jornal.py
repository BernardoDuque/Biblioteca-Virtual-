class Jornal:
    def __init__(self, id, titulo, descricao, datas_edicao, disponibilidade, leitura_online):
        self.id=id
        self.titulo=titulo
        self.descricao=descricao
        self.datas_edicao=datas_edicao
        self.disponibilidade=disponibilidade
        self.leitura_online=leitura_online