class Livro:
    def __init__(self, id, titulo, descricao, autor, detalhe_autor, categoria, disponibilidade, reserva):
        self.id=id
        self.titulo=titulo
        self.descricao=descricao
        self.autor=autor
        self.detalhe_autor=detalhe_autor
        self.categoria=categoria
        self.disponibilidade=disponibilidade
        self.reserva=reserva